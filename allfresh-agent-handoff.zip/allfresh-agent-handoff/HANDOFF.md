# HANDOFF — allfresh-ops에 성과분석 에이전트 추가 (클로드 코드용 작업 지시)

> 이 폴더는 다른 클로드 세션(claude.ai)에서 설계·검증한 결과의 인수인계다.
> **먼저 `INTEGRATION.md`를 읽고**, 아래 작업을 이 repo(allfresh-ops, React/Vite + Deno 엣지함수)에 반영한다.

## 배경 (왜)
올프레쉬는 자사몰(카페24)·스마트스토어·카카오톡스토어 멀티채널 셀러다. 기존 ops 앱엔 "성과분석(실데이터 진단)" 기능이 없다. 이걸 추가한다.

## ★ 절대 원칙 (어기면 숫자가 망가짐)
**계산은 코드(compute), 해석만 LLM.** 업로드된 CSV/xlsx를 LLM(gpt-4o-mini)에 통째로 주지 말 것 — 숫자를 지어낸다. 프런트에서 코드로 지표를 계산해 `analyze-performance` 함수에 "이미 계산된 metrics"로 넘긴다. (함수 입력 계약 = `functions/analyze-performance/index.ts`의 `PerfRequest` 타입)

## 작업 (5가지)
1. **함수 추가**: `functions/analyze-performance/index.ts` (이 폴더에 제공됨) 그대로 repo의 `functions/`로 복사. 기존 함수 템플릿(Deno.serve, corsHeaders, OPENAI_API_KEY, gpt-4o-mini, mock 폴백) 준수 확인.
2. **의존성 추가**: `package.json`에 CSV/xlsx 파싱 라이브러리가 없음 → `papaparse`(CSV)와 `xlsx`(SheetJS, 엑셀) 추가.
3. **compute 유틸 생성**: `src/lib/performanceCompute.js`(또는 유사) — 업로드 파일을 파싱해 채널별 metrics JSON 생성. 매핑은 `INTEGRATION.md §3`(카페24 CSV 컬럼 → metrics) 참조. 핵심 규칙: 매출은 판매처(role='destination')에만, 어트리뷰션은 role='ad'로 비용·기여만. 기여이익 = 순매출 − 원가 − 채널수수료 − 광고비 − 할인/포인트.
4. **페이지 생성**: `src/pages/PerformanceAnalysis.jsx` — 업로드 → compute → analyze-performance 호출 → 결과 렌더(Executive Summary, 인사이트 카드[관찰→해석→실행→검증], 리스크, 한계). 기존 `src/pages/StrategyDashboard.jsx` 패턴 재사용.
5. **라우팅 등록**: `src/pages.config.js`의 `PAGES`에 `PerformanceAnalysis` import + 등록 1줄.
6. (선택) 결과를 `Analysis` 엔티티에 `{type:'performance', ...}`로 저장 → History 연동.

## 검증 체크
- [ ] 매출이 destination 채널에만 (attribution을 매출에 더하지 않음)
- [ ] 시즌 왜곡 가드(seasonFlag/comparison) — 올프레쉬는 명절 의존이 극심, 직전기간 비교 금지
- [ ] 플랫폼 ROAS 단순 합산 금지, 효율은 블렌디드(MER)
- [ ] `npm run dev`로 페이지 실제 렌더·업로드 테스트

## 품질 업그레이드(선택)
`analyze-performance`의 호출 모델을 OpenAI → **Claude API(api.anthropic.com)** 로 바꾸면 `skills/`의 방법론과 같은 엔진으로 해석 품질이 올라간다.

## 참고 자료(이 폴더)
- `INTEGRATION.md` — 통합 가이드 + 카페24 CSV→metrics 매핑(필독)
- `functions/analyze-performance/index.ts` — 해석 엔진(입력/출력 계약 포함)
- `skills/allfresh-integrated-analysis/` — 방법론(과일선물세트 잣대·크로스채널 통합 규칙). 함수 시스템 프롬프트의 원본.
- `런준비_체크리스트.md` — 채널별 수집 목록(운영 참고)
